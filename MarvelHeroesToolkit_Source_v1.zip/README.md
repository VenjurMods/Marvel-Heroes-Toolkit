# Marvel Heroes Toolkit

A modding and utility toolkit for Marvel Heroes Omega private servers. Created by **VenjurMods**.

## 🔧 Features

- Convert `.json` account exports to `.db` database files
- Automatically patch player metadata during conversion
- Merge multiple `.db` files into a single database
- GUI with tabbed interface and "About" menu
- Full icon support and embedded resources

---

## 🧱 How to Build (.exe)

1. **Install Python** (3.10+ recommended)
2. Install dependencies:
   ```bash
   pip install pyinstaller pandas
   ```
3. Build with PyInstaller:
   ```bash
   pyinstaller marvel_heroes_toolkit.spec
   ```
4. Your `.exe` will be created in the `dist/` folder:
   ```
   dist/Marvel Heroes Toolkit.exe
   ```

---

## 🚀 How to Use the App

1. Launch the app (`.py` or `.exe`)
2. Use **Convert JSON to DB** tab:
   - Select a `.json` export
   - Choose an output `.db` file
   - Click **Convert**
3. Use **Merge DB Files** tab:
   - Select a source `.db` (to copy from)
   - Select a target `.db` (to merge into)
   - Set an output path
   - Click **Merge**

Player metadata (`StartTarget`, `AOIVolume`, etc.) is patched using `player_metadata_patch.json`.

---

## 📁 Included Files

- `marvel_heroes_toolkit.py` — main GUI application
- `marvel_heroes_toolkit.spec` — PyInstaller build file
- `schema.sql` — SQLite schema required for database creation
- `player_metadata_patch.json` — auto-patch metadata file
- `marvel_toolkit.ico` — application icon
- `version.txt` — embedded metadata for `.exe`

---

## ✨ About

> Marvel Heroes Toolkit  
> Version 1.0  
> Created by VenjurMods  
> https://github.com/VenjurMods/Marvel-Heroes-Toolkit
