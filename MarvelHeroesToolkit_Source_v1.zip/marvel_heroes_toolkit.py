
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import sqlite3
import json
import base64
import os
import pandas as pd

import sys
import os

def resource_path(relative_path):
    """ Get absolute path to resource in development or PyInstaller bundle """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)


class JsonToDbApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Marvel Heroes Toolkit")
        self.root.iconbitmap(resource_path("marvel_toolkit.ico"))

        menubar = tk.Menu(self.root)
        helpmenu = tk.Menu(menubar, tearoff=0)
        helpmenu.add_command(label="About", command=self.show_about)
        menubar.add_cascade(label="Help", menu=helpmenu)
        self.root.config(menu=menubar)


        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True)

        self.tab_convert = ttk.Frame(self.notebook)
        self.tab_merge = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_convert, text="Convert JSON to DB")
        self.notebook.add(self.tab_merge, text="Merge DB Files")

        self.create_convert_widgets()
        self.create_merge_widgets()

    def create_convert_widgets(self):
        self.json_path_var = tk.StringVar()
        self.output_db_var = tk.StringVar()

        ttk.Label(self.tab_convert, text="JSON File:").grid(row=0, column=0, sticky="e")
        ttk.Entry(self.tab_convert, textvariable=self.json_path_var, width=50).grid(row=0, column=1)
        ttk.Button(self.tab_convert, text="Browse", command=self.browse_json).grid(row=0, column=2)

        ttk.Label(self.tab_convert, text="Output DB:").grid(row=1, column=0, sticky="e")
        ttk.Entry(self.tab_convert, textvariable=self.output_db_var, width=50).grid(row=1, column=1)
        ttk.Button(self.tab_convert, text="Browse", command=self.browse_output).grid(row=1, column=2)

        ttk.Button(self.tab_convert, text="Convert", command=self.convert).grid(row=2, column=1, pady=10)

        self.status_text = tk.Text(self.tab_convert, height=10, wrap="word")
        self.status_text.grid(row=3, column=0, columnspan=3, pady=10)

    def create_merge_widgets(self):
        self.merge_source_var = tk.StringVar()
        self.merge_target_var = tk.StringVar()
        self.output_merge_var = tk.StringVar()

        ttk.Label(self.tab_merge, text="Source DB (copy from):").grid(row=0, column=0, sticky="e")
        ttk.Entry(self.tab_merge, textvariable=self.merge_source_var, width=50).grid(row=0, column=1)
        ttk.Button(self.tab_merge, text="Browse", command=self.browse_source_db).grid(row=0, column=2)

        ttk.Label(self.tab_merge, text="Target DB (base):").grid(row=1, column=0, sticky="e")
        ttk.Entry(self.tab_merge, textvariable=self.merge_target_var, width=50).grid(row=1, column=1)
        ttk.Button(self.tab_merge, text="Browse", command=self.browse_target_db).grid(row=1, column=2)

        ttk.Label(self.tab_merge, text="Output Merged DB:").grid(row=2, column=0, sticky="e")
        ttk.Entry(self.tab_merge, textvariable=self.output_merge_var, width=50).grid(row=2, column=1)
        ttk.Button(self.tab_merge, text="Browse", command=self.browse_merge_output).grid(row=2, column=2)

        ttk.Button(self.tab_merge, text="Merge", command=self.merge_files).grid(row=3, column=1, pady=10)

    def browse_json(self):
        path = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json")])
        if path:
            self.json_path_var.set(path)

    def browse_output(self):
        path = filedialog.asksaveasfilename(defaultextension=".db", filetypes=[("SQLite DB", "*.db")])
        if path:
            self.output_db_var.set(path)

    def browse_source_db(self):
        path = filedialog.askopenfilename(filetypes=[("SQLite DB Files", "*.db")])
        if path:
            self.merge_source_var.set(path)

    def browse_target_db(self):
        path = filedialog.askopenfilename(filetypes=[("SQLite DB Files", "*.db")])
        if path:
            self.merge_target_var.set(path)

    def browse_merge_output(self):
        path = filedialog.asksaveasfilename(defaultextension=".db", filetypes=[("SQLite DB", "*.db")])
        if path:
            self.output_merge_var.set(path)

    def log(self, message):
        self.status_text.insert(tk.END, message + "\n")
        self.status_text.see(tk.END)

    def convert(self):
        json_path = self.json_path_var.get()
        db_path = self.output_db_var.get()

        if not os.path.isfile(json_path):
            messagebox.showerror("Error", "Invalid JSON file.")
            return

        try:
            with open(json_path, "r") as f:
                data = json.load(f)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load JSON: {e}")
            return

        if os.path.exists(db_path):
            os.remove(db_path)

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        try:
            cursor.executescript(open(resource_path("schema.sql")).read())

            cursor.execute("""
            INSERT INTO Account (Id, Email, PlayerName, PasswordHash, Salt, UserLevel, Flags)
            VALUES (?, ?, ?, ?, ?, ?, ?);
            """, (
                data["Id"],
                data["Email"],
                data["PlayerName"],
                base64.b64decode(data["PasswordHash"]),
                base64.b64decode(data["Salt"]),
                data["UserLevel"],
                data["Flags"]
            ))

            player = data["Player"]
            cursor.execute("""
            INSERT INTO Player (DbGuid, ArchiveData)
            VALUES (?, ?);
            """, (
                player["DbGuid"],
                base64.b64decode(player["ArchiveData"])
            ))

            for key, table in [
                ("Avatars", "Avatar"),
                ("Items", "Item"),
                ("TeamUps", "TeamUp"),
                ("ControlledEntities", "ControlledEntity")
            ]:
                if key in data:
                    for entry in data[key]:
                        cursor.execute(f"""
                        INSERT INTO {table} (DbGuid, ContainerDbGuid, InventoryProtoGuid, Slot, EntityProtoGuid, ArchiveData)
                        VALUES (?, ?, ?, ?, ?, ?)""", (
                            entry["DbGuid"],
                            entry["ContainerDbGuid"],
                            entry["InventoryProtoGuid"],
                            entry["Slot"],
                            entry["EntityProtoGuid"],
                            base64.b64decode(entry["ArchiveData"])
                        ))

            with open(resource_path("player_metadata_patch.json"), "r") as meta_file:
                metadata = json.load(meta_file)

            cursor.execute("""
            UPDATE Player
            SET StartTarget = ?, 
                StartTargetRegionOverride = ?, 
                AOIVolume = ?, 
                GazillioniteBalance = ?;
            """, (
                metadata["StartTarget"],
                metadata["StartTargetRegionOverride"],
                metadata["AOIVolume"],
                metadata["GazillioniteBalance"]
            ))

            self.log("✔ Metadata patched from JSON.")
            conn.commit()
            conn.close()
            self.log(f"✅ Conversion complete! Output: {db_path}")

        except Exception as e:
            conn.close()
            messagebox.showerror("Error", f"Conversion failed: {e}")

    def merge_files(self):
        source_path = self.merge_source_var.get()
        target_path = self.merge_target_var.get()
        output_path = self.output_merge_var.get()

        if not source_path or not target_path or not output_path:
            messagebox.showerror("Error", "Please select source, target, and output DB files.")
            return

        if os.path.exists(output_path):
            os.remove(output_path)

        conn_target = sqlite3.connect(output_path)

        try:
            with open(resource_path("schema.sql"), "r") as f:
                schema_sql = f.read()
            conn_target.executescript(schema_sql)

            for file_path in [source_path, target_path]:
                if file_path.endswith(".db"):
                    conn_source = sqlite3.connect(file_path)
                    for table in ["Account", "Player", "Avatar", "Item", "TeamUp", "ControlledEntity"]:
                        df = pd.read_sql_query(f"SELECT * FROM {table};", conn_source)
                        df.to_sql(table, conn_target, if_exists="append", index=False)
                    conn_source.close()

            conn_target.commit()
            conn_target.close()
            messagebox.showinfo("Success", f"Merged files saved to: {output_path}")

        except Exception as e:
            conn_target.close()
            messagebox.showerror("Error", f"Failed to merge files: {e}")


    def show_about(self):
        messagebox.showinfo(
            "About",
            "Marvel Heroes Toolkit\nVersion 1.0\nCreated by VenjurMods\nhttps://github.com/VenjurMods/Marvel-Heroes-Toolkit"
        )


def main():
    root = tk.Tk()
    app = JsonToDbApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()