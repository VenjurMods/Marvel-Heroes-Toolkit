CREATE TABLE Account (
    Id INTEGER PRIMARY KEY,
    Email TEXT NOT NULL,
    PlayerName TEXT NOT NULL,
    PasswordHash BLOB NOT NULL,
    Salt BLOB NOT NULL,
    UserLevel INTEGER NOT NULL,
    Flags INTEGER NOT NULL
);

CREATE TABLE Player (
    DbGuid INTEGER PRIMARY KEY,
    ArchiveData BLOB,
    StartTarget INTEGER,
    StartTargetRegionOverride INTEGER,
    AOIVolume INTEGER,
    GazillioniteBalance INTEGER
);

CREATE TABLE Avatar (
    DbGuid INTEGER,
    ContainerDbGuid INTEGER,
    InventoryProtoGuid INTEGER,
    Slot INTEGER,
    EntityProtoGuid INTEGER,
    ArchiveData BLOB
);

CREATE TABLE TeamUp (
    DbGuid INTEGER,
    ContainerDbGuid INTEGER,
    InventoryProtoGuid INTEGER,
    Slot INTEGER,
    EntityProtoGuid INTEGER,
    ArchiveData BLOB
);

CREATE TABLE Item (
    DbGuid INTEGER,
    ContainerDbGuid INTEGER,
    InventoryProtoGuid INTEGER,
    Slot INTEGER,
    EntityProtoGuid INTEGER,
    ArchiveData BLOB
);

CREATE TABLE ControlledEntity (
    DbGuid INTEGER,
    ContainerDbGuid INTEGER,
    InventoryProtoGuid INTEGER,
    Slot INTEGER,
    EntityProtoGuid INTEGER,
    ArchiveData BLOB
);

CREATE INDEX IX_Avatar_ContainerDbGuid ON Avatar (ContainerDbGuid);
CREATE INDEX IX_TeamUp_ContainerDbGuid ON TeamUp (ContainerDbGuid);
CREATE INDEX IX_Item_ContainerDbGuid ON Item (ContainerDbGuid);
CREATE INDEX IX_ControlledEntity_ContainerDbGuid ON ControlledEntity (ContainerDbGuid);